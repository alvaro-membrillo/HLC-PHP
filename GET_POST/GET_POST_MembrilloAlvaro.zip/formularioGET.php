<!doctype html>
<html>
<head>
    <title>
    </title>
</head>
<body>
    <form method=get action=get_post.php>
        Nombre: <input type="text" name="usuario">
        <br>
        <input type ="Submit" name"Enviar" value="Enviar">
    </form>

    <!--Get muestra la informacion del input que se envia en la URL-->
</body>
</html>