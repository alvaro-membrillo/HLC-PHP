<!doctype html>
<html>
<head>
    <title>
    </title>
</head>
<body>
     
    <form method=post action=get_post.php>
        Nombre: <input type="text" name="usuario">
        <br>
        <input type ="Submit" name"Enviar" value="Enviar">
    </form>

    <!--Post no muestra la informacion que se envia en el input en la URL-->
    
</body>
</html>